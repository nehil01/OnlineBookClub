import React, { useState } from 'react';
import './Auth.css'; // Shared CSS for both Login and Register
import { useNavigate } from 'react-router-dom';

const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    // Basic validation
    if (!name || !email || !password) {
      setError('Please fill in all fields.');
      return;
    }

    // Simulate registration logic (replace with actual API call)
    setError('');
    alert('Registration successful!');
    navigate('/login'); // Redirect to login page after registration
  };

  return (
    <section className='auth'>
      <div className='container'>
        <div className='section-title'>
          <h2>Register</h2>
        </div>

        <div className='auth-content'>
          <form className='auth-form' onSubmit={handleSubmit}>
            {error && <p className='error-message'>{error}</p>}
            <div className='input-group'>
              <label htmlFor='name'>Name</label>
              <input
                type='text'
                id='name'
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder='Enter your name'
                required
              />
            </div>

            <div className='input-group'>
              <label htmlFor='email'>Email</label>
              <input
                type='email'
                id='email'
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder='Enter your email'
                required
              />
            </div>

            <div className='input-group'>
              <label htmlFor='password'>Password</label>
              <input
                type='password'
                id='password'
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder='Enter your password'
                required
              />
            </div>

            <button type='submit' className='submit-btn'>
              Register
            </button>
          </form>

          <p className='auth-link'>
            Already have an account? <a href='/login'>Login here</a>.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Register;