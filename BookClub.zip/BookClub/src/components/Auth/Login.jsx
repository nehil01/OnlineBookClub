import React, { useState } from 'react';
import './Auth.css'; // Shared CSS for both Login and Register
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    // Basic validation
    if (!email || !password) {
      setError('Please fill in all fields.');
      return;
    }

    // Simulate login logic (replace with actual API call)
    if (email === 'user@example.com' && password === 'password123') {
      setError('');
      alert('Login successful!');
      navigate('/profile'); // Redirect to profile page after login
    } else {
      setError('Invalid email or password.');
    }
  };

  return (
    <section className='auth'>
      <div className='container'>
        <div className='section-title'>
          <h2>Login</h2>
        </div>

        <div className='auth-content'>
          <form className='auth-form' onSubmit={handleSubmit}>
            {error && <p className='error-message'>{error}</p>}
            <div className='input-group'>
              <label htmlFor='email'>Email</label>
              <input
                type='email'
                id='email'
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder='Enter your email'
                required
              />
            </div>

            <div className='input-group'>
              <label htmlFor='password'>Password</label>
              <input
                type='password'
                id='password'
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder='Enter your password'
                required
              />
            </div>

            <button type='submit' className='submit-btn'>
              Login
            </button>
          </form>

          <p className='auth-link'>
            Don't have an account? <a href='/register'>Register here</a>.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Login;