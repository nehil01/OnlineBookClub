import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import Loading from "../Loader/Loader";
import coverImg from "../../images/cover_not_found.jpg";
import "./BookDetails.css";
import { FaArrowLeft } from "react-icons/fa";
import { useNavigate } from 'react-router-dom';

const URL = "https://openlibrary.org/works/";

const BookDetails = () => {
  const { id } = useParams();
  const [loading, setLoading] = useState(false);
  const [book, setBook] = useState(null);
  const [review, setReview] = useState('');
  const [rating, setRating] = useState(0);
  const [image, setImage] = useState(null); // State for uploaded image
  const [reviewsList, setReviewsList] = useState([]); // State for reviews
  const [comment, setComment] = useState(''); // State for comments
  const [commentsList, setCommentsList] = useState({}); // State to store comments for each review
  const navigate = useNavigate();

  useEffect(() => {
    setLoading(true);
    async function getBookDetails() {
      try {
        const response = await fetch(`${URL}${id}.json`);
        const data = await response.json();
        console.log(data);

        if (data) {
          const { description, title, covers, subject_places, subject_times, subjects } = data;
          const newBook = {
            description: description ? description.value : "No description found",
            title: title,
            cover_img: covers ? `https://covers.openlibrary.org/b/id/${covers[0]}-L.jpg` : coverImg,
            subject_places: subject_places ? subject_places.join(", ") : "No subject places found",
            subject_times: subject_times ? subject_times.join(", ") : "No subject times found",
            subjects: subjects ? subjects.join(", ") : "No subjects found"
          };
          setBook(newBook);
        } else {
          setBook(null);
        }
        setLoading(false);
      } catch (error) {
        console.log(error);
        setLoading(false);
      }
    }
    getBookDetails();
  }, [id]);

  // Handle review submission
  const handleReviewSubmit = (e) => {
    e.preventDefault();
    if (review && rating > 0) {
      const newReview = {
        review,
        rating,
        image: image ? URL.createObjectURL(image) : null, // Store image URL
        id: Date.now(), // Unique ID based on timestamp
        timestamp: new Date().toLocaleString(), // Add timestamp for the feed
        comments: [], // Initialize empty comments array for this review
      };
      setReviewsList([newReview, ...reviewsList]); // Add new review to the top of the list
      setReview('');
      setRating(0);
      setImage(null); // Reset image after submission
    }
  };

  // Handle image upload
  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(file);
    }
  };

  // Handle comment submission
  const handleCommentSubmit = (reviewId) => {
    if (comment.trim()) {
      const newComment = {
        text: comment,
        id: Date.now(), // Unique ID based on timestamp
        timestamp: new Date().toLocaleString(), // Add timestamp for the comment
      };

      // Update comments for the specific review
      setCommentsList((prevComments) => ({
        ...prevComments,
        [reviewId]: [...(prevComments[reviewId] || []), newComment],
      }));

      setComment(''); // Reset comment input
    }
  };

  if (loading) return <Loading />;

  return (
    <section className='book-details'>
      <div className='container'>
        <button type='button' className='flex flex-c back-btn' onClick={() => navigate("/book")}>
          <FaArrowLeft size={22} />
          <span className='fs-18 fw-6'>Go Back</span>
        </button>

        <div className='book-details-content grid'>
          <div className='book-details-img'>
            <img src={book?.cover_img} alt="cover img" />
          </div>
          <div className='book-details-info'>
            <div className='book-details-item title'>
              <span className='fw-6 fs-24'>{book?.title}</span>
            </div>
            <div className='book-details-item description'>
              <span>{book?.description}</span>
            </div>
            <div className='book-details-item'>
              <span className='fw-6'>Subject Places: </span>
              <span className='text-italic'>{book?.subject_places}</span>
            </div>
            <div className='book-details-item'>
              <span className='fw-6'>Subject Times: </span>
              <span className='text-italic'>{book?.subject_times}</span>
            </div>
            <div className='book-details-item'>
              <span className='fw-6'>Subjects: </span>
              <span>{book?.subjects}</span>
            </div>
          </div>
        </div>

        {/* Share Review Section */}
        <div className='share-review-section'>
          <h3 className='review-form-title fs-26 ls-1'>Share Your Review</h3>
          <form className='review-form' onSubmit={handleReviewSubmit}>
            <div className='input-group'>
              <textarea
                value={review}
                onChange={(e) => setReview(e.target.value)}
                placeholder='Write your review here...'
                rows={5}
                required
              />
            </div>

            <div className='input-group'>
              <label htmlFor='rating'>Rating (1 to 5):</label>
              <input
                type='number'
                id='rating'
                value={rating}
                onChange={(e) => setRating(Number(e.target.value))}
                min="1"
                max="5"
                required
              />
            </div>

            {/* <div className='input-group'>
              <label htmlFor='image'>Upload Image (Optional)</label>
              <input
                type='file'
                id='image'
                accept='image/*'
                onChange={handleImageUpload}
              />
              {image && (
                <div className='image-preview'>
                  <img
                    src={URL.createObjectURL(image)}
                    alt='Preview'
                    className='preview-image'
                  />
                </div>
              )}
            </div> */}

            <button type='submit' className='submit-btn'>
              Submit Review
            </button>
          </form>
        </div>

        {/* Reviews Feed Section */}
        <div className='reviews-feed'>
          <h3 className='feed-title fs-20 ls-1'>Recent Reviews</h3>
          {reviewsList.length === 0 ? (
            <p className='no-reviews'>No reviews yet. Be the first to share yours!</p>
          ) : (
            <div className='feed-list'>
              {reviewsList.map((reviewItem) => (
                <div key={reviewItem.id} className='feed-item'>
                  <div className='feed-item-header'>
                    <span className='feed-item-rating'>
                      <strong>Rating:</strong> {reviewItem.rating} / 5
                    </span>
                    <span className='feed-item-timestamp'>
                      {reviewItem.timestamp}
                    </span>
                  </div>
                  {reviewItem.image && (
                    <div className='feed-item-image'>
                      <img
                        src={reviewItem.image}
                        alt='Review'
                        className='review-image'
                      />
                    </div>
                  )}
                  <p className='feed-item-review'>{reviewItem.review}</p>

                  {/* Comment Section for Each Review */}
                  <div className='comment-section'>
                    <h4 className='comment-title fs-18 ls-1'>Comments</h4>
                    <div className='comment-list'>
                      {(commentsList[reviewItem.id] || []).map((comment) => (
                        <div key={comment.id} className='comment-item'>
                          <p className='comment-text'>{comment.text}</p>
                          <span className='comment-timestamp'>
                            {comment.timestamp}
                          </span>
                        </div>
                      ))}
                    </div>
                    <div className='comment-input-group'>
                      <textarea
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        placeholder='Write a comment...'
                        rows={2}
                      />
                      <button
                        type='button'
                        className='comment-submit-btn'
                        onClick={() => handleCommentSubmit(reviewItem.id)}
                      >
                        Post Comment
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default BookDetails;