import React, { useState } from 'react';
import './Reviews.css';

const Reviews = () => {
  const [review, setReview] = useState('');
  const [rating, setRating] = useState(0);
  const [image, setImage] = useState(null); // State for uploaded image
  const [reviewsList, setReviewsList] = useState([]);

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    if (review && rating > 0) {
      const newReview = {
        review,
        rating,
        image: image ? URL.createObjectURL(image) : null, // Store image URL
        id: Date.now(), // Unique ID based on timestamp
        timestamp: new Date().toLocaleString(), // Add timestamp for the feed
      };
      setReviewsList([newReview, ...reviewsList]); // Add new review to the top of the list
      setReview('');
      setRating(0);
      setImage(null); // Reset image after submission
    }
  };

  // Handle image upload
  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(file);
    }
  };

  return (
    <section className='reviews'>
      <div className='container'>
        <div className='section-title'>
          <h2>Share Your Review</h2>
        </div>

        <div className='reviews-content grid'>
          {/* Review Form */}
          <div className='share-review-form'>
            <h2 className='review-form-title fs-26 ls-1'>Submit Your Review</h2>
            <form className='review-form' onSubmit={handleSubmit}>
              <div className='input-group'>
                <textarea
                  value={review}
                  onChange={(e) => setReview(e.target.value)}
                  placeholder='Write your review here...'
                  rows={5}
                  required
                />
              </div>

              <div className='input-group'>
                <label htmlFor='rating'>Rating (1 to 5):</label>
                <input
                  type='number'
                  id='rating'
                  value={rating}
                  onChange={(e) => setRating(Number(e.target.value))}
                  min="1"
                  max="5"
                  required
                />
              </div>

              <div className='input-group'>
                <label htmlFor='image'>Upload Image (Optional)</label>
                <input
                  type='file'
                  id='image'
                  accept='image/*'
                  onChange={handleImageUpload}
                />
                {image && (
                  <div className='image-preview'>
                    <img
                      src={URL.createObjectURL(image)}
                      alt='Preview'
                      className='preview-image'
                    />
                  </div>
                )}
              </div>

              <button type='submit' className='submit-btn'>
                Submit Review
              </button>
            </form>
          </div>

          {/* Feed Section */}
          <div className='feed-section'>
            <h3 className='feed-title fs-20 ls-1'>Recent Reviews</h3>
            {reviewsList.length === 0 ? (
              <p className='no-reviews'>No reviews yet. Be the first to share yours!</p>
            ) : (
              <div className='feed-list'>
                {reviewsList.map((reviewItem) => (
                  <div key={reviewItem.id} className='feed-item'>
                    <div className='feed-item-header'>
                      <span className='feed-item-rating'>
                        <strong>Rating:</strong> {reviewItem.rating} / 5
                      </span>
                      <span className='feed-item-timestamp'>
                        {reviewItem.timestamp}
                      </span>
                    </div>
                    {reviewItem.image && (
                      <div className='feed-item-image'>
                        <img
                          src={reviewItem.image}
                          alt='Review'
                          className='review-image'
                        />
                      </div>
                    )}
                    <p className='feed-item-review'>{reviewItem.review}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Reviews;