import React from 'react';
import "./About.css";
import aboutImg from "../../images/about-img.jpg";

const About = () => {
  return (
    <section className='about'>
      <div className='container'>
        <div className='section-title'>
          <h2>About</h2>
        </div>

        <div className='about-content grid'>
          <div className='about-img'>
            <img src = {aboutImg} alt = "" />
          </div>
          <div className='about-text'>
            <h2 className='about-title fs-26 ls-1'>About BookHub</h2>
            <p className='fs-17'>Welcome to BookHub, your gateway to a thriving online book club community! We are passionate about connecting readers from around the world to share, discuss, and explore the joy of reading. Whether you're a casual reader or a dedicated bookworm, our platform offers a space for you to discover new books, connect with like-minded individuals, and engage in meaningful conversations.</p>
            <p className='fs-17'>At BookHub, we aim to foster a vibrant, inclusive community that celebrates the power of books to inspire, educate, and connect people. Dive into a world of stories, ideas, and friendships. Download BookHub and make every page count. Happy reading!
</p>
          </div>
        </div>
      </div>
    </section>
  )
}

export default About
