import React from 'react';
import './Profile.css';
import profileImg from '../../images/profile-img.jpeg';

const Profile = () => {
  return (
    <section className='profile'>
      <div className='container'>
        <div className='section-title'>
          <h2>Profile</h2>
        </div>

        <div className='profile-content grid'>
          <div className='profile-img'>
            <img src={profileImg} alt="Profile" />
          </div>
          <div className='profile-details'>
            <h2 className='profile-name fs-26 ls-1'>John Doe</h2> &nbsp;
            <p className='fs-17'>
              Welcome to your personal profile page! Here, you can view and manage your account details, track your reading progress, and review your activity within the BookHub community.
            </p>  &nbsp;
            <p className='fs-17'>
              <strong>Email:</strong> john.doe@example.com
            </p>  &nbsp;
            <p className='fs-17'>
              <strong>Joined:</strong> January 15, 2023
            </p>  &nbsp;
            <p className='fs-17'>
              <strong>Total Reviews:</strong> 15
            </p>
          </div>
        </div>

        <div className='user-activity'>
          <h3 className='fs-20 ls-1'>Your Activity</h3>
          <div className='activity-item fs-17'>
            <p><strong>Last Book Reviewed:</strong> "The Great Gatsby" - ⭐⭐⭐⭐</p>
          </div>
          <div className='activity-item fs-17'>
            <p><strong>Favorite Genre:</strong> Fiction</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Profile;